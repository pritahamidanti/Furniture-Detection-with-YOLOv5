# DATA_UAS > 2024-07-19 1:03pm
https://universe.roboflow.com/prita-hamidanti-dpbne/data_uas-7fxjj

Provided by a Roboflow user
License: CC BY 4.0

